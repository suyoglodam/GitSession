package com.ts;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	private int id;
	private int flatNo;
	private String city;
	private int pinCode;
	private String state;
	@OneToOne
	private Employee emp;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public Address() {
	}

	public Address(int id, int flatNo, String city, int pinCode, String state, Employee emp) {
		this.id = id;
		this.flatNo = flatNo;
		this.city = city;
		this.pinCode = pinCode;
		this.state = state;
		this.emp = emp;
	}

}
