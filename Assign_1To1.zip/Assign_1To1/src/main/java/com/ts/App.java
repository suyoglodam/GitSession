package com.ts;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration()
							    			.configure()
							    			.addAnnotatedClass(Employee.class)
							    			.addAnnotatedClass(Address.class);
    	SessionFactory sf= cfg.buildSessionFactory();
    	Session session=sf.openSession();
    	session.beginTransaction();
    	//-----------------------------
    	Employee e1=new Employee(1, "Suyog", "CSE", 90000);
    	Employee e2=new Employee(2, "Shiva", "CSE", 96000);
    	Employee e3=new Employee(3, "Ram", "IT", 45000);
    	Employee e4=new Employee(4, "Krishna", "MECH", 40000);
    	session.save(e1);
    	session.save(e2);
    	session.save(e3);
    	session.save(e4);
    	
    	Address a1=new Address(11, 101, "Amaravati", 007, "MH", e1);
    	Address a2=new Address(12, 102, "Ayodhya", 004, "UP", e3);
    	Address a3=new Address(13, 103, "Ujjain", 001, "MP", e2);
    	Address a4=new Address(14, 104, "Puri", 003, "OD", e4);
    	session.save(a1);
    	session.save(a2);
    	session.save(a3);
    	session.save(a4);
    	//-----------------------------
    	session.getTransaction().commit();
    	session.close();
    }
}
